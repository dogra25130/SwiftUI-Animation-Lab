# TrendScout

# Auth-Module Architecture
<img width="814" alt="Auth Module" src="https://github.com/user-attachments/assets/f4c81a19-677e-41d2-8a75-ec1154f87f0f">
