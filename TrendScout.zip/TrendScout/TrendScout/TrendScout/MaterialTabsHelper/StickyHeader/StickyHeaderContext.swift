//
//  Created by Timothy Moose on 1/23/24.
//

import Foundation

public typealias StickyHeaderContext = HeaderContext<NoTab>
