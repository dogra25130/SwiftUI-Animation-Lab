//
//  Created by Timothy Moose on 1/23/24.
//

import Foundation

public enum NoTab: Hashable {
    case none
}
