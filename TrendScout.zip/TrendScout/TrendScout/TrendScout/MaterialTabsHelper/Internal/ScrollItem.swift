//
//  Created by Timothy Moose on 1/14/24.
//

import Foundation

public enum ScrollItem: Hashable {
    case item
}
