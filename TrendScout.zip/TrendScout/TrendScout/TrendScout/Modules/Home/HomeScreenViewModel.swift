//
//  HomeScreenViewModel.swift
//  TrendScout
//
//  Created by Abhishek Dogra on 23/07/24.
//

import Foundation
class HomeScreenViewModel: ObservableObject {
    
}
